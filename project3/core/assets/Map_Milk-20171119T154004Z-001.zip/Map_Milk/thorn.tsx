<?xml version="1.0" encoding="UTF-8"?>
<tileset name="thorn" tilewidth="8" tileheight="8" tilecount="25" columns="5">
 <image source="thorn.png" width="40" height="40"/>
</tileset>
