<?xml version="1.0" encoding="UTF-8"?>
<tileset name="stage5" tilewidth="8" tileheight="8" tilecount="14400" columns="160">
 <image source="stage5.png" width="1280" height="720"/>
</tileset>
