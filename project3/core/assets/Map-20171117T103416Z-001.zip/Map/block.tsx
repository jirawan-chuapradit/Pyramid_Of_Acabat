<?xml version="1.0" encoding="UTF-8"?>
<tileset name="block" tilewidth="8" tileheight="8" tilecount="185" columns="37">
 <image source="block.png" trans="0000ff" width="300" height="40"/>
</tileset>
