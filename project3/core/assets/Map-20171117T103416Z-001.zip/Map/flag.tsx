<?xml version="1.0" encoding="UTF-8"?>
<tileset name="flag2" tilewidth="8" tileheight="8" tilecount="512" columns="16">
 <image source="flag.png" trans="0000ff" width="128" height="256"/>
</tileset>
