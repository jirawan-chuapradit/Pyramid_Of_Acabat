<?xml version="1.0" encoding="UTF-8"?>
<tileset name="background" tilewidth="8" tileheight="8" tilecount="14400" columns="160">
 <image source="background.png" trans="0000ff" width="1280" height="720"/>
</tileset>
