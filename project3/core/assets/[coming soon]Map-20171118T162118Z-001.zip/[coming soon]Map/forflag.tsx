<?xml version="1.0" encoding="UTF-8"?>
<tileset name="PC Computer - MapleStory - Kampung Village Tiles" tilewidth="8" tileheight="8" tilecount="3268" columns="76">
 <image source="PC Computer - MapleStory - Kampung Village Tiles.png" width="610" height="347"/>
</tileset>
