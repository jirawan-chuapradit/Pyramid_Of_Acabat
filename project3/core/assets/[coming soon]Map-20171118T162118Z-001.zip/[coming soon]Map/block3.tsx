<?xml version="1.0" encoding="UTF-8"?>
<tileset name="PC Computer - MapleStory - CBD Tiles" tilewidth="8" tileheight="8" tilecount="3150" columns="105">
 <image source="PC Computer - MapleStory - CBD Tiles.png" width="843" height="241"/>
</tileset>
