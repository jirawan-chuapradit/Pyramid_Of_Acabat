<?xml version="1.0" encoding="UTF-8"?>
<tileset name="stage3" tilewidth="8" tileheight="8" tilecount="10800" columns="120">
 <image source="stage3.png" width="960" height="720"/>
</tileset>
