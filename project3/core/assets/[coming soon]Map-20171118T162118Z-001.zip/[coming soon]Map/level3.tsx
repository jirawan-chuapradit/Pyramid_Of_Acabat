<?xml version="1.0" encoding="UTF-8"?>
<tileset name="level3" tilewidth="8" tileheight="8" tilecount="14400" columns="160">
 <image source="level3.jpg" width="1280" height="720"/>
</tileset>
