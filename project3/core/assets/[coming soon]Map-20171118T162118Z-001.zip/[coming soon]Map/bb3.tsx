<?xml version="1.0" encoding="UTF-8"?>
<tileset name="PC Computer - MapleStory - Magatia Tiles" tilewidth="8" tileheight="8" tilecount="1700" columns="68">
 <image source="PC Computer - MapleStory - Magatia Tiles.png" width="550" height="204"/>
</tileset>
