<?xml version="1.0" encoding="UTF-8"?>
<tileset name="stage4" tilewidth="8" tileheight="8" tilecount="19200" columns="160">
 <image source="stage4.png" width="1280" height="960"/>
</tileset>
