<?xml version="1.0" encoding="UTF-8"?>
<tileset name="block_3" tilewidth="8" tileheight="8" tilecount="2500" columns="50">
 <image source="23718407_1777759465866660_886797821_n.png" width="400" height="400"/>
</tileset>
